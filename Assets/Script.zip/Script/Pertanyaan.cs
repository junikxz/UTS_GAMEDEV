// Pertanyaan.cs
[System.Serializable]
public class Pertanyaan
{
    public string teksPertanyaan;
    public string[] jawaban = new string[4];
    public int indeksJawabanBenar;
}