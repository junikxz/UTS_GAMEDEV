using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class DialogueBubbleUI : MonoBehaviour
{
    // Variabel publik ini akan menjadi slot di Inspector
    public TextMeshProUGUI dialogueText;
    public Button nextButton;
}